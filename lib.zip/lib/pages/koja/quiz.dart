import 'package:flutter/material.dart';

class Kojsur extends StatefulWidget {
  const Kojsur({super.key});

  @override
  State<Kojsur> createState() => _KojsurState();
}

class _KojsurState extends State<Kojsur> {
  @override
  Widget build(BuildContext context) {
    return Scaffold();
  }
}
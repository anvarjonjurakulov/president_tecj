import 'package:flutter/material.dart';

class Pediquiz extends StatefulWidget {
  const Pediquiz({super.key});

  @override
  State<Pediquiz> createState() => _PediquizState();
}

class _PediquizState extends State<Pediquiz> {
  @override
  Widget build(BuildContext context) {
    return Scaffold();
  }
}
import 'package:flutter/material.dart';

class PediInfo extends StatefulWidget {
  const PediInfo({super.key});

  @override
  State<PediInfo> createState() => _PediInfoState();
}

class _PediInfoState extends State<PediInfo> {
  @override
  Widget build(BuildContext context) {
    return Scaffold();
  }
}
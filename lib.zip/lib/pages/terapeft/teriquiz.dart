import 'package:flutter/material.dart';

class Teriquiz extends StatefulWidget {
  const Teriquiz({super.key});

  @override
  State<Teriquiz> createState() => _TeriquizState();
}

class _TeriquizState extends State<Teriquiz> {
  @override
  Widget build(BuildContext context) {
    return Scaffold();
  }
}
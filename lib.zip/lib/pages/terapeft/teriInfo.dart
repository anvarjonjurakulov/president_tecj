import 'package:flutter/material.dart';

class TeriInfo extends StatefulWidget {
  const TeriInfo({super.key});

  @override
  State<TeriInfo> createState() => _TeriInfoState();
}

class _TeriInfoState extends State<TeriInfo> {
  @override
  Widget build(BuildContext context) {
    return Scaffold();
  }
}